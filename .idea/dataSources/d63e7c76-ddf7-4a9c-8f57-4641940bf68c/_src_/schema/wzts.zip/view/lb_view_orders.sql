CREATE VIEW `lb_view_orders` AS
  /* ALGORITHM=UNDEFINED */
  SELECT
    `wzts`.`lb_orders_list`.`id`            AS `id`,
    `wzts`.`lb_orders_list`.`cangwei`       AS `cangwei`,
    `wzts`.`lb_orders_list`.`gongyingshang` AS `gongyingshang`,
    `wzts`.`lb_orders_list`.`lururen`       AS `lururen`,
    `wzts`.`lb_orders_list`.`cost_price`    AS `cost_price`,
    `wzts`.`lb_orders_list`.`refund_status` AS `refund_status`,
    `wzts`.`lb_orders_list`.`order_id`      AS `order_id`,
    `wzts`.`lb_orders_list`.`oid`           AS `oid`,
    `wzts`.`lb_orders_list`.`oid_status`    AS `oid_status`,
    `wzts`.`lb_orders_list`.`outer_sku_id`  AS `outer_sku_id`,
    `wzts`.`lb_orders_list`.`title`         AS `title`,
    `wzts`.`lb_orders_list`.`price`         AS `price`,
    `wzts`.`lb_orders_list`.`num`           AS `num`,
    `wzts`.`lb_orders_list`.`order_from`    AS `order_from`,
    `wzts`.`lb_orders_list`.`payment`       AS `payment`,
    `wzts`.`lb_orders_list`.`total_fee`     AS `total_fee`,
    `wzts`.`lb_orders_list`.`discount_fee`  AS `discount_fee`,
    `wzts`.`lb_orders_list`.`adjust_fee`    AS `adjust_fee`,
    `wzts`.`lb_orders_list`.`end_time`      AS `end_time`,
    `wzts`.`lb_orders_list`.`consign_time`  AS `consign_time`,
    `wzts`.`lb_orders`.`qudao`              AS `qudao`,
    `wzts`.`lb_orders`.`dianpu`             AS `dianpu`,
    `wzts`.`lb_orders`.`created_time`       AS `created_time`,
    `wzts`.`lb_orders`.`pay_time`           AS `pay_time`,
    `wzts`.`lb_orders`.`order_status`       AS `order_status`,
    `wzts`.`lb_orders`.`trade_from`         AS `trade_from`,
    `wzts`.`lb_warehouse`.`name`            AS `cangwei_name`,
    `wzts`.`lb_orders_list`.`jiandang_time` AS `jiandang_time`,
    `wzts`.`lb_orders_list`.`pinlei`        AS `pinlei`,
    `wzts`.`lb_orders_list`.`xilie`         AS `xilie`
  FROM ((`wzts`.`lb_orders`
    JOIN `wzts`.`lb_orders_list` ON ((`wzts`.`lb_orders_list`.`order_id` = `wzts`.`lb_orders`.`order_id`))) JOIN
    `wzts`.`lb_warehouse` ON ((`wzts`.`lb_orders_list`.`cangwei` = `wzts`.`lb_warehouse`.`id`)))